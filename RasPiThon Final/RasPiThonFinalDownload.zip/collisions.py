import pygame

class CheckCol:
    def alienshoot:
        